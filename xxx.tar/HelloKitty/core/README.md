# Hellokitty-Ransomware-Source-Code
The hellokitty ransomware was first identified in November 2020. It's sourcecode was leaked on the darknet forum XSS. I’ve made this information available here soley for the purposes of research and analysis.

References
- https://www.bleepingcomputer.com/news/security/hellokitty-ransomware-source-code-leaked-on-hacking-forum/

![](https://media.licdn.com/dms/image/D4D12AQFH6YzfN84TRQ/article-cover_image-shrink_720_1280/0/1698946403132?e=1706140800&v=beta&t=GPnG-tJYeYNTtLIZHJs-q4uJEcQrwnC_Z_EspTJYoRs)

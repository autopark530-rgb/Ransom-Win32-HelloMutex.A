#pragma once

// size = 1120

  uint8_t ntru_private_bytes[1120] = { 'p','r','i','v','a','t','e','k','e','y','D','E','A','D','B','E','E','F',0 };
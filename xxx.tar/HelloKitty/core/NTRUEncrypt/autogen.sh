#! /bin/sh

autoreconf --install

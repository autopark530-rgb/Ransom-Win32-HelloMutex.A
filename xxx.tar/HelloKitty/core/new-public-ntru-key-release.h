#pragma once

// size = 1027

	uint8_t ntru_public_bytes[1027] = { 'p','u','b','l','i','c','k','e','y','D','E','A','D','B','E','E','F',0 };
#pragma once

#include <windows.h>

unsigned int xcrc32 (const unsigned char *buf, int len, unsigned int init);